@extends('layouts.template.master')
@section('page-style')
@endsection
@section('content')
    <personero-component></personero-component>
@endsection
@section('page-script')
@endsection
@extends('layouts.template.master')
@section('page-style')
@endsection
@section('content')
    <dashboard-component></dashboard-component>
@endsection
@section('page-script')
@endsection
@extends('layouts.template.master')
@section('page-style')
@endsection
@section('content')
    <persona-component></persona-component>
@endsection
@section('page-script')
@endsection
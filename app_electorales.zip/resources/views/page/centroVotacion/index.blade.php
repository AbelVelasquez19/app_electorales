@extends('layouts.template.master')
@section('page-style')
@endsection
@section('content')
    <centro-votacion-component></centro-votacion-component>
@endsection
@section('page-script')
@endsection
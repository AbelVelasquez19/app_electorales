@extends('layouts.template.master')
@section('page-style')
@endsection
@section('content')
    <partido-component></partido-component>
@endsection
@section('page-script')
@endsection
@extends('layouts.template.master')
@section('page-style')
@endsection
@section('content')
    <mesa-component></mesa-component>
@endsection
@section('page-script')
@endsection
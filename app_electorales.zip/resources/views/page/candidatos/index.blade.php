@extends('layouts.template.master')
@section('page-style')
@endsection
@section('content')
    <candidato-component></candidato-component>
@endsection
@section('page-script')
@endsection

<?php $__env->startSection('page-style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <mesa-component></mesa-component>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\app_electorales\resources\views/page/mesa/index.blade.php ENDPATH**/ ?>
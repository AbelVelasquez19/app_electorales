
<?php $__env->startSection('page-style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <nue-cent-vot-component :url-province="'<?php echo e(route('province')); ?>'"
                            :url-distric="'<?php echo e(route('district')); ?>'"
                            :url-coregimient="'<?php echo e(route('coregimient')); ?>'"
                            :url-maps="'<?php echo e(route('maps')); ?>'"
                            :url-guardar="'<?php echo e(route('guardarCentroCosto')); ?>'"
                            >
    </nue-cent-vot-component>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\app_electorales\resources\views/page/centroVotacionNuevo.blade.php ENDPATH**/ ?>
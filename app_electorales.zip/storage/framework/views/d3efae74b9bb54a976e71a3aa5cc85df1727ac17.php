<!DOCTYPE html>

<html
  lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>"
  class="light-style customizer-hide"
  dir="ltr"
  data-theme="theme-default"
  data-assets-path="../../assets/"
  data-template="vertical-menu-template"
>
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
    />

    <title>Login Cover - Pages | Vuexy - Bootstrap Admin Template</title>

    <meta name="description" content="" />

    <?php echo $__env->make('layouts.acceso.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('page-style'); ?>
  </head>

  <body>
    <!-- Content -->
    <?php echo $__env->yieldContent('content'); ?>
    <!-- fin Content -->
    <?php echo $__env->make('layouts.acceso.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('page-script'); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\app_electorales\resources\views/layouts/acceso/master.blade.php ENDPATH**/ ?>